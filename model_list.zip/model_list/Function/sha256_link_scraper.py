from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException, WebDriverException

def get_sha256_and_link(url):
    """
    从目标网页提取 SHA256 值和下载链接
    Args:
        url (str): 目标网页URL
    Returns:
        tuple: (sha256, download_link) 成功返回元组，失败返回None
    """
    print(f"\n[开始] 正在处理URL: {url}")

    options = Options()
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--log-level=3")
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.page_load_strategy = 'eager'

    driver = None
    try:
        print("[1/6] 正在启动 Chrome 浏览器...")
        driver = webdriver.Chrome(options=options)
        print("[2/6] 浏览器启动成功，正在加载页面...")
        
        driver.get(url)
        print(f"[3/6] 页面加载完成 | 标题: {driver.title} | URL: {driver.current_url}")
        
        # 检查页面是否有效（404/500错误）
        if "404" in driver.title or "500" in driver.title:
            print("[!] 错误: 页面返回404/500状态")
            return None
        
        print("[4/6] 正在等待关键信息出现（最多10秒）...")
        WebDriverWait(driver, 10).until(
            lambda d: "文件信息总览" in d.page_source or "SHA256" in d.page_source
        )
        print("[5/6] 关键信息加载完成，正在提取SHA256和下载链接...")
        
        # 提取 SHA256
        page_text = driver.find_element(By.TAG_NAME, "body").text
        if "SHA256：" in page_text:
            sha256 = page_text.split("SHA256：")[1].split()[0]
            print(f"[✓] 成功提取 SHA256: {sha256}")
        else:
            print("[!] 警告: 页面中未找到'SHA256：'文本")
            return None
        
        # 尝试多种方式提取下载链接
        download_link = None
        download_selectors = [
            "//a[contains(text(),'下载模型')]",  # 包含"下载模型"文本的链接
            "//a[contains(text(),'下载')]",     # 包含"下载"文本的链接
            "//a[contains(@class,'download')]", # 包含download类的链接
            "//a[contains(@href,'download')]",  # 包含download的链接
            "//button[contains(text(),'下载')]/..",  # 下载按钮的父元素
            "//*[contains(text(),'文件下载')]/following::a[1]"  # "文件下载"文本后的第一个链接
        ]
        
        for selector in download_selectors:
            try:
                element = driver.find_element(By.XPATH, selector)
                download_link = element.get_attribute("href")
                if download_link and download_link.startswith(('http://', 'https://')):
                    print(f"[✓] 成功提取下载链接: {download_link}")
                    break
            except:
                continue
        
        if not download_link:
            print("[!] 警告: 无法找到有效的下载链接")
            print("调试信息 - 页面中所有链接:")
            all_links = driver.find_elements(By.TAG_NAME, "a")
            for link in all_links[:10]:  # 只打印前10个链接避免太多输出
                print(f"链接文本: {link.text}, href: {link.get_attribute('href')}")
            return None
        
        return (sha256, download_link)

    except TimeoutException:
        print("[!] 超时: 10秒内未找到'文件信息总览'或'SHA256'关键字")
        print(f"当前页面源码片段: {driver.page_source[:500]}...")
        return None
    except WebDriverException as e:
        print(f"[!] 浏览器异常: {str(e)}")
        return None
    except Exception as e:
        print(f"[!] 未知异常: {type(e).__name__}: {str(e)}")
        return None
    finally:
        if driver:
            print("[6/6] 正在关闭浏览器...")
            driver.quit()
        print("[结束] 处理完成\n")