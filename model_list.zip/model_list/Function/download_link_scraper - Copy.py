# Function/download_link_scraper.py
import json
import time
from typing import Optional, Set

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException

def _enable_perf_logging(options: Options):
    options.set_capability("goog:loggingPrefs", {"performance": "ALL"})

def _looks_like_download_url(u: str) -> bool:
    u = (u or "").lower()
    return (u.endswith(".zip") or "/download" in u or "download=" in u or "/raw/" in u or "/resolve/" in u)

def _prefer_resolve(u: str) -> bool:
    return "/resolve/" in (u or "")

def _extract_download_from_perf_logs(driver, seen_ids: Set[str]) -> Optional[str]:
    try:
        logs = driver.get_log("performance")
    except Exception:
        return None

    candidate = None
    for entry in logs:
        try:
            msg = json.loads(entry.get("message", "{}")).get("message", {})
            method = msg.get("method", "")
            params = msg.get("params", {})
            if method == "Network.requestWillBeSent":
                req = params.get("request", {}) or {}
                rid = params.get("requestId", "")
                url = req.get("url", "") or ""
                if rid and rid not in seen_ids and _looks_like_download_url(url):
                    seen_ids.add(rid)
                    # LFS 直链（无 /resolve/）常出现在这里
                    candidate = url
            elif method == "Network.responseReceived":
                res = params.get("response", {}) or {}
                rid = params.get("requestId", "")
                url = res.get("url", "") or ""
                if rid and rid not in seen_ids and _looks_like_download_url(url):
                    seen_ids.add(rid)
                    # 有时 /resolve/ 会短暂停留；优先返回 /resolve/
                    if _prefer_resolve(url):
                        return url
                    candidate = candidate or url
        except Exception:
            continue
    return candidate

def get_download_link(url):
    """
    目标：优先返回 UI 的稳定链接 `/resolve/.../file.zip`。
    步骤：
      1) 定位下载按钮；若其本身或上层 <a> 的 href 含 `/resolve/`，直接返回该 href。
      2) 否则点击按钮，监听 Network 日志，若捕获到 `/resolve/` 优先返回；再不行才返回 LFS 直链。
    """
    print(f"\n[开始] 正在处理URL: {url}")

    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--log-level=3")
    options.add_argument("--window-size=1366,1000")
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.page_load_strategy = 'eager'
    _enable_perf_logging(options)

    driver = None
    try:
        print("[1/6] 启动 Chrome ...")
        driver = webdriver.Chrome(options=options)
        try:
            driver.execute_cdp_cmd("Network.enable", {})
        except Exception:
            pass

        print("[2/6] 打开页面 ...")
        driver.get(url)
        print(f"[i] 标题: {driver.title}")
        if "404" in driver.title or "500" in driver.title:
            print("[!] 错误页（标题含 404/500）")
            return None

        print("[3/6] 等主体渲染（<=10s） ...")
        WebDriverWait(driver, 10).until(lambda d: d.find_elements(By.TAG_NAME, "body"))

        print("[4/6] 定位下载按钮 ...")
        xpaths = [
            "//a[normalize-space()='下载']",
            "//a[contains(., '下载')]",
            "//button[normalize-space()='下载']",
            "//button[contains(., '下载')]",
            "//*[@aria-label and contains(@aria-label,'下载')]",
            "//*[@title and contains(@title,'下载')]",
            "//a[contains(@class,'download')]",
            "//button[contains(@class,'download')]",
            "//*[name()='svg']/ancestor::a[contains(@href,'/resolve/')][1]",
            "//a[contains(@href,'/resolve/')]",  # 直接有 resolve 的链接
        ]

        btn = None
        for xp in xpaths:
            try:
                btn = WebDriverWait(driver, 2).until(EC.element_to_be_clickable((By.XPATH, xp)))
                if btn:
                    break
            except TimeoutException:
                continue

        if not btn:
            print("[!] 未找到可点击的下载按钮")
            return None

        # 先看按钮自身或最近的 <a> 是否携带 /resolve/ 链接
        href = btn.get_attribute("href")
        if not href:
            try:
                a_parent = btn.find_element(By.XPATH, "./ancestor::a[1]")
                href = a_parent.get_attribute("href")
            except Exception:
                href = None

        if href and _prefer_resolve(href):
            print(f"[✓] 直接获取到 /resolve/ 链接: {href}")
            return href

        # 若按钮没给 resolve 链接，再点击并监听网络
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
        time.sleep(0.2)
        before_handles = set(driver.window_handles)
        driver.execute_script("arguments[0].click();", btn)

        print("[5/6] 监听下载请求（优先 /resolve/） ...")
        seen_ids: Set[str] = set()
        deadline = time.time() + 8.0
        candidate_url = None

        while time.time() < deadline:
            time.sleep(0.3)

            # A) 新窗口里可能短暂出现 /resolve/，先捕获它
            now_handles = set(driver.window_handles)
            new_handles = now_handles - before_handles
            if new_handles:
                nh = list(new_handles)[0]
                driver.switch_to.window(nh)
                cur = driver.current_url or ""
                if _prefer_resolve(cur):
                    print(f"[✓] 新窗口 /resolve/ 链接: {cur}")
                    return cur
                if _looks_like_download_url(cur):
                    candidate_url = candidate_url or cur  # 可能是 LFS，先记为候选

            # B) 从 performance 日志里找网络请求
            url_from_logs = _extract_download_from_perf_logs(driver, seen_ids)
            if url_from_logs:
                if _prefer_resolve(url_from_logs):
                    print(f"[✓] 网络日志捕获 /resolve/ 链接: {url_from_logs}")
                    return url_from_logs
                # 不是 resolve（大概率是 LFS 直链），先当候选
                candidate_url = candidate_url or url_from_logs

        # 只在实在找不到 /resolve/ 时，才返回候选（可能是 LFS）
        if candidate_url:
            print(f"[i] 未捕获到 /resolve/，返回候选直链（可能为 LFS）: {candidate_url}")
            return candidate_url

        print("[!] 未捕获到下载链接")
        return None

    except TimeoutException:
        print("[!] 超时：页面或按钮等待失败")
        return None
    except WebDriverException as e:
        print(f"[!] 浏览器异常: {e}")
        return None
    except Exception as e:
        print(f"[!] 未知异常: {type(e).__name__}: {e}")
        return None
    finally:
        if driver:
            print("[6/6] 关闭浏览器")
            driver.quit()
