import json
import os
import sys
from typing import Optional, Dict, List, Union

class ModelListManager:
    def __init__(self):
        """Initialize with default settings"""
        self.model_list_file = "model_list.json"
        self.model_list = {"LLM": [], "WhiteList": []}  # 默认结构
        
        if os.path.exists(self.model_list_file):
            with open(self.model_list_file, "r", encoding="utf-8") as f:
                loaded_data = json.load(f)
                # 确保两个主要字段都存在
                self.model_list["LLM"] = loaded_data.get("LLM", [])
                self.model_list["WhiteList"] = loaded_data.get("WhiteList", [])
    
    def _save_model_list(self):
        """Save current state to model_list.json"""
        with open(self.model_list_file, "w", encoding="utf-8") as f:
            json.dump(self.model_list, f, indent=4, ensure_ascii=False)
    
    def _find_model_index(self, item_name: str, list_type: str = "LLM") -> Optional[int]:
        """Find model/entry index by exact name/bundleName match (case sensitive)"""
        if list_type not in ["LLM", "WhiteList"]:
            raise ValueError("Invalid list type. Must be 'LLM' or 'WhiteList'")
            
        key = "name" if list_type == "LLM" else "bundleName"
        
        for i, item in enumerate(self.model_list[list_type]):
            if item[key] == item_name:
                return i
        return None
    
    def add_item(self, json_filename: str, list_type: str = "LLM") -> bool:
        """Add model/entry from JSON file in current directory"""
        try:
            if list_type not in ["LLM", "WhiteList"]:
                raise ValueError("Invalid list type. Must be 'LLM' or 'WhiteList'")
                
            with open(json_filename, "r", encoding="utf-8") as f:
                item_data = json.load(f)
            
            key = "name" if list_type == "LLM" else "bundleName"
            if self._find_model_index(item_data[key], list_type) is not None:
                print(f"{list_type} item '{item_data[key]}' already exists")
                return False
            
            self.model_list[list_type].append(item_data)
            self._save_model_list()
            print(f"{list_type} item '{item_data[key]}' added successfully")
            return True
        except FileNotFoundError:
            print(f"Error: File '{json_filename}' not found")
            return False
        except Exception as e:
            print(f"Error adding {list_type} item: {str(e)}")
            return False
    
    def delete_item(self, item_name: str, list_type: str = "LLM") -> bool:
        """Delete model/entry by exact name/bundleName match"""
        try:
            if list_type not in ["LLM", "WhiteList"]:
                raise ValueError("Invalid list type. Must be 'LLM' or 'WhiteList'")
                
            index = self._find_model_index(item_name, list_type)
            if index is None:
                print(f"{list_type} item '{item_name}' not found")
                return False
            
            self.model_list[list_type].pop(index)
            self._save_model_list()
            print(f"{list_type} item '{item_name}' deleted successfully")
            return True
        except Exception as e:
            print(f"Error deleting {list_type} item: {str(e)}")
            return False
    
    def update_item(self, json_filename: str, list_type: str = "LLM") -> bool:
        """Update model/entry from JSON file in current directory"""
        try:
            if list_type not in ["LLM", "WhiteList"]:
                raise ValueError("Invalid list type. Must be 'LLM' or 'WhiteList'")
                
            with open(json_filename, "r", encoding="utf-8") as f:
                new_data = json.load(f)
            
            key = "name" if list_type == "LLM" else "bundleName"
            index = self._find_model_index(new_data[key], list_type)
            if index is None:
                print(f"{list_type} item '{new_data[key]}' not found (use add instead)")
                return False
            
            self.model_list[list_type][index] = new_data
            self._save_model_list()
            print(f"{list_type} item '{new_data[key]}' updated successfully")
            return True
        except Exception as e:
            print(f"Error updating {list_type} item: {str(e)}")
            return False


def main():
    if len(sys.argv) < 4:
        print("Usage:")
        print("  For LLM models:")
        print("    python Gen_final_model_list.py md add <json_filename>")
        print("    python Gen_final_model_list.py md update <json_filename>")
        print("    python Gen_final_model_list.py md delete <model_name>")
        print("  For WhiteList entries:")
        print("    python Gen_final_model_list.py wl add <json_filename>")
        print("    python Gen_final_model_list.py wl update <json_filename>")
        print("    python Gen_final_model_list.py wl delete <bundleName>")
        sys.exit(1)
    
    list_type = sys.argv[1].lower()
    command = sys.argv[2].lower()
    argument = sys.argv[3]
    
    if list_type not in ["md", "wl"]:
        print(f"Error: First argument must be 'md' (for models) or 'wl' (for whitelist)")
        sys.exit(1)
    
    if command not in ["add", "update", "delete"]:
        print(f"Error: Second argument must be 'add', 'update' or 'delete'")
        sys.exit(1)
    
    manager = ModelListManager()
    target_list = "LLM" if list_type == "md" else "WhiteList"
    
    if command == "add":
        if not argument.endswith('.json'):
            print(f"Error: '{argument}' must be a .json file")
            sys.exit(1)
        manager.add_item(argument, target_list)
    elif command == "update":
        if not argument.endswith('.json'):
            print(f"Error: '{argument}' must be a .json file")
            sys.exit(1)
        manager.update_item(argument, target_list)
    elif command == "delete":
        manager.delete_item(argument, target_list)
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)

if __name__ == "__main__":
    main()