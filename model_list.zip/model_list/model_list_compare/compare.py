import json
import difflib
from pathlib import Path

def load_and_format_json(file_path):
    """加载并格式化 JSON（保留原始顺序，仅缩进）"""
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return json.dumps(data, indent=2, ensure_ascii=False)

def generate_full_diff_html(file1, file2, output_html="full_diff.html"):
    """生成完整文件的 HTML 差异报告"""
    json1 = load_and_format_json(file1).splitlines(keepends=True)
    json2 = load_and_format_json(file2).splitlines(keepends=True)

    # 关键设置：强制显示所有行（即使无差异）
    differ = difflib.HtmlDiff(
        tabsize=2,
        wrapcolumn=80,
        charjunk=difflib.IS_CHARACTER_JUNK  # 禁用行内差异检测（避免字符级高亮混乱）
    )
    html_diff = differ.make_file(
        json1, 
        json2,
        fromdesc=f"OLD: {file1}",
        todesc=f"NEW: {file2}",
        context=False  # 关闭上下文折叠，显示全部行
    )

    with open(output_html, 'w', encoding='utf-8') as f:
        f.write(html_diff)
    print(f"✅ 完整差异报告已生成: {Path(output_html).resolve()}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="生成完整 JSON 文件的 HTML 差异报告")
    parser.add_argument("file1", help="旧版 JSON 文件")
    parser.add_argument("file2", help="新版 JSON 文件")
    parser.add_argument("--output", default="model_list_diff.html", help="输出 HTML 文件名")
    args = parser.parse_args()
    generate_full_diff_html(args.file1, args.file2, args.output)