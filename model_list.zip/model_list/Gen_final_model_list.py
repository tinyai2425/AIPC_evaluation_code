import json
import os
import sys
from typing import Optional, Dict, List, Union

class ModelListManager:
    def __init__(self):
        """Initialize with default settings"""
        self.model_list_file = "model_list.json"
        self.model_list = {"LLM": [], "WhiteList": []}  # 默认结构

        if os.path.exists(self.model_list_file):
            with open(self.model_list_file, "r", encoding="utf-8") as f:
                loaded_data = json.load(f)
                # 确保两个主要字段都存在
                self.model_list["LLM"] = loaded_data.get("LLM", [])
                self.model_list["WhiteList"] = loaded_data.get("WhiteList", [])

    def _save_model_list(self):
        """Save current state to model_list.json"""
        with open(self.model_list_file, "w", encoding="utf-8") as f:
            json.dump(self.model_list, f, indent=4, ensure_ascii=False)

    def _find_model_index(self, item_name: str, list_type: str = "LLM") -> Optional[int]:
        """Find model/entry index by exact name/bundleName match (case sensitive)"""
        if list_type not in ["LLM", "WhiteList"]:
            raise ValueError("Invalid list type. Must be 'LLM' or 'WhiteList'")

        key = "name" if list_type == "LLM" else "bundleName"

        for i, item in enumerate(self.model_list[list_type]):
            if item.get(key) == item_name:
                return i
        return None

    # -------------------------
    # 基础的增删改（单条）
    # -------------------------
    def add_item(self, json_filename: str, list_type: str = "LLM") -> bool:
        """Add model/entry from JSON file in current directory"""
        try:
            if list_type not in ["LLM", "WhiteList"]:
                raise ValueError("Invalid list type. Must be 'LLM' or 'WhiteList'")

            with open(json_filename, "r", encoding="utf-8") as f:
                item_data = json.load(f)

            key = "name" if list_type == "LLM" else "bundleName"
            if key not in item_data:
                raise ValueError(f"Input JSON missing key '{key}'")

            if self._find_model_index(item_data[key], list_type) is not None:
                print(f"{list_type} item '{item_data[key]}' already exists")
                return False

            self.model_list[list_type].append(item_data)
            self._save_model_list()
            print(f"{list_type} item '{item_data[key]}' added successfully")
            return True
        except FileNotFoundError:
            print(f"Error: File '{json_filename}' not found")
            return False
        except Exception as e:
            print(f"Error adding {list_type} item: {str(e)}")
            return False

    def delete_item(self, item_name: str, list_type: str = "LLM") -> bool:
        """Delete model/entry by exact name/bundleName match"""
        try:
            if list_type not in ["LLM", "WhiteList"]:
                raise ValueError("Invalid list type. Must be 'LLM' or 'WhiteList'")

            index = self._find_model_index(item_name, list_type)
            if index is None:
                print(f"{list_type} item '{item_name}' not found")
                return False

            self.model_list[list_type].pop(index)
            self._save_model_list()
            print(f"{list_type} item '{item_name}' deleted successfully")
            return True
        except Exception as e:
            print(f"Error deleting {list_type} item: {str(e)}")
            return False

    def update_item(self, json_filename: str, list_type: str = "LLM") -> bool:
        """Update model/entry from JSON file in current directory"""
        try:
            if list_type not in ["LLM", "WhiteList"]:
                raise ValueError("Invalid list type. Must be 'LLM' or 'WhiteList'")

            with open(json_filename, "r", encoding="utf-8") as f:
                new_data = json.load(f)

            key = "name" if list_type == "LLM" else "bundleName"
            if key not in new_data:
                raise ValueError(f"Input JSON missing key '{key}'")

            index = self._find_model_index(new_data[key], list_type)
            if index is None:
                print(f"{list_type} item '{new_data[key]}' not found (use add instead)")
                return False

            self.model_list[list_type][index] = new_data
            self._save_model_list()
            print(f"{list_type} item '{new_data[key]}' updated successfully")
            return True
        except Exception as e:
            print(f"Error updating {list_type} item: {str(e)}")
            return False

    # -------------------------
    # 只增不减的白名单合并（批量） + 保持顺序 + appId 一致性检查
    # -------------------------
    @staticmethod
    def _extract_whitelist(data: Union[Dict, List]) -> List[Dict]:
        """
        从输入数据中提取 WhiteList 数组：
        - 若 data 是 list，直接视为 WhiteList
        - 若 data 是 dict，优先取 'WhiteList'（不区分大小写）
        """
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for k in data.keys():
                if k.lower() == "whitelist":
                    wl = data[k]
                    if isinstance(wl, list):
                        return wl
        raise ValueError("Input JSON must be a list or a dict containing 'WhiteList' list")

    @staticmethod
    def _bundle_name_of(item: Dict) -> Optional[str]:
        return item.get("bundleName")

    @staticmethod
    def _app_id_of(item: Dict) -> Optional[str]:
        return item.get("appId")

    def merge_whitelist_add_only(self, json_filename: str, strict: bool = True) -> bool:
        """
        从 json_filename 中批量合并 WhiteList（只增不减）并对齐顺序：
        1) 解析输入文件中的 WhiteList
        2) 校验规则（strict=True）：
           - 旧 WhiteList 的每个 bundleName 必须出现在输入文件中，否则报错（防止“删旧”）
           - 对于每个旧项，若 bundleName 一致但 appId 不一致（或任一侧缺失），报错
        3) 按输入文件的顺序构造最终 WhiteList（即**新顺序 = 输入文件顺序**）
           - 若输入文件有重复 bundleName，仅保留第一条，其余忽略并告警
        4) 保存 model_list.json
        """
        try:
            if not os.path.exists(json_filename):
                print(f"Error: File '{json_filename}' not found")
                return False

            with open(json_filename, "r", encoding="utf-8") as f:
                incoming_raw = json.load(f)

            incoming_list_raw = self._extract_whitelist(incoming_raw)

            # —— 过滤并记录问题项 ——
            filtered_incoming: List[Dict] = []
            invalid_no_bundle = 0
            seen = set()
            dup_bundle = []

            for it in incoming_list_raw:
                if not isinstance(it, dict):
                    invalid_no_bundle += 1
                    continue
                bn = self._bundle_name_of(it)
                if not bn:
                    invalid_no_bundle += 1
                    continue
                if bn in seen:
                    dup_bundle.append(bn)
                    # 只保留第一次出现的条目，后面重复的忽略
                    continue
                seen.add(bn)
                filtered_incoming.append(it)

            if invalid_no_bundle > 0:
                print(f"Warning: {invalid_no_bundle} incoming item(s) missing 'bundleName' or not dict; ignored")
            if dup_bundle:
                print(f"Warning: Duplicated bundleName(s) in incoming file (kept first occurrence): {sorted(set(dup_bundle))}")

            current_list = self.model_list["WhiteList"]

            # 构建 {bundleName: item} 映射，便于对比 appId
            current_map = {}
            for it in current_list:
                if isinstance(it, dict) and self._bundle_name_of(it):
                    current_map[self._bundle_name_of(it)] = it

            incoming_map = {self._bundle_name_of(it): it for it in filtered_incoming}

            current_names = set(current_map.keys())
            incoming_names = set(incoming_map.keys())

            # —— 严格检查：不可“删旧项” + appId 必须一致 ——
            if strict:
                # 1) 旧项缺失检查
                missing_in_incoming = sorted(name for name in current_names if name not in incoming_names)
                if missing_in_incoming:
                    print("ERROR: Merge aborted because the incoming file would REMOVE existing whitelist entries.")
                    print("Missing bundleName(s) not found in incoming file:")
                    for name in missing_in_incoming:
                        print(f"  - {name}")
                    print("\n原则：白名单只增不减。请修正输入文件后重试。")
                    return False

                # 2) appId 一致性检查
                mismatch = []
                missing_app_id = []
                for name in current_names:
                    cur_app = self._app_id_of(current_map[name])
                    inc_app = self._app_id_of(incoming_map.get(name, {}))
                    if cur_app is None or inc_app is None:
                        missing_app_id.append((name, cur_app, inc_app))
                    elif str(cur_app) != str(inc_app):
                        mismatch.append((name, cur_app, inc_app))

                if missing_app_id or mismatch:
                    print("ERROR: Merge aborted due to appId inconsistency.")
                    if missing_app_id:
                        print("Items with missing appId (either current or incoming):")
                        for name, cur_app, inc_app in missing_app_id:
                            print(f"  - {name}: current.appId={cur_app}, incoming.appId={inc_app}")
                    if mismatch:
                        print("Items with different appId between current and incoming:")
                        for name, cur_app, inc_app in mismatch:
                            print(f"  - {name}: current.appId={cur_app}  !=  incoming.appId={inc_app}")
                    print("\n请先修正 appId 再合并。")
                    return False

            # —— 目标：顺序 = 输入文件顺序；内容 = 输入的条目（保证含有全部旧项） ——
            final_whitelist_in_order: List[Dict] = filtered_incoming[:]  # 直接采用输入顺序和内容

            # （此处无需“追加旧项”，因为 strict 已确保旧项都在 incoming 内）
            previous_count = len(current_list)
            final_count = len(final_whitelist_in_order)
            added_count = max(0, final_count - previous_count)

            # 写回
            self.model_list["WhiteList"] = final_whitelist_in_order
            self._save_model_list()

            print("WhiteList merge (add-only, ordered by incoming file) finished:")
            print(f"  - Previous WhiteList count : {previous_count}")
            print(f"  - Incoming valid count     : {len(filtered_incoming)}")
            print(f"  - Final WhiteList count    : {final_count}")
            print(f"  - New entries added        : {added_count}")
            print("  - Order aligned to incoming file.")
            return True

        except Exception as e:
            print(f"Error merging WhiteList: {str(e)}")
            return False


def print_usage_and_exit():
    print("Usage:")
    print("  For LLM models:")
    print("    python Gen_final_model_list.py md add <json_filename>")
    print("    python Gen_final_model_list.py md update <json_filename>")
    print("    python Gen_final_model_list.py md delete <model_name>")
    print("  For WhiteList entries (single item):")
    print("    python Gen_final_model_list.py wl add <json_filename>")
    print("    python Gen_final_model_list.py wl update <json_filename>")
    print("    python Gen_final_model_list.py wl delete <bundleName>")
    print("  For WhiteList merge (add-only, from file, keep incoming order):")
    print("    python Gen_final_model_list.py wl all <json_filename>")
    sys.exit(1)


def main():
    if len(sys.argv) < 3:
        print_usage_and_exit()

    list_type = sys.argv[1].lower()
    command = sys.argv[2].lower()

    if list_type not in ["md", "wl"]:
        print(f"Error: First argument must be 'md' (for models) or 'wl' (for whitelist)")
        sys.exit(1)

    manager = ModelListManager()
    target_list = "LLM" if list_type == "md" else "WhiteList"

    # wl all <json_filename>
    if list_type == "wl" and command == "all":
        if len(sys.argv) < 4:
            print("Error: Missing <json_filename> for 'wl all'")
            sys.exit(1)
        json_filename = sys.argv[3]
        if not json_filename.endswith(".json"):
            print(f"Error: '{json_filename}' must be a .json file")
            sys.exit(1)
        ok = manager.merge_whitelist_add_only(json_filename, strict=True)
        sys.exit(0 if ok else 2)

    # 其它命令需要第三参数
    if len(sys.argv) < 4:
        print_usage_and_exit()

    argument = sys.argv[3]

    if command not in ["add", "update", "delete"]:
        print(f"Error: Second argument must be 'add', 'update', 'delete', or 'all' (wl only)")
        sys.exit(1)

    if command in ["add", "update"]:
        if not argument.endswith('.json'):
            print(f"Error: '{argument}' must be a .json file")
            sys.exit(1)
        if command == "add":
            manager.add_item(argument, target_list)
        else:
            manager.update_item(argument, target_list)
    elif command == "delete":
        manager.delete_item(argument, target_list)
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
